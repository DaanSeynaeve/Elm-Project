cp mainStorage.html main.html
elm-make Main.elm --output=main.js